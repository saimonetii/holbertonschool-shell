# Add to previous design

## Must Add

* 1 server

* 1 load-balancer (HAproxy) configured as cluster with the other one

* Split components (web server, application server, database) with their own server


## Questions

* Why did we add each additional element?

[URL to design of a three server web infrastructure](https://imgur.com/a/U594TaV)
