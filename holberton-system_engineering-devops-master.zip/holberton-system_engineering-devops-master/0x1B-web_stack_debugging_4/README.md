0x1B. Web stack debugging #4

